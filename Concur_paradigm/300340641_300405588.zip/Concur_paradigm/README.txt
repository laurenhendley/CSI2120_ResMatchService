Students:
Lauren Hendley [lhend093@uottawa.ca, SN: 300405588]
Acadia Marchand [amarc139@uottawa.ca, SN: 300340641]

Github repo for the project: https://github.com/laurenhendley/CSI2120_ResMatchService